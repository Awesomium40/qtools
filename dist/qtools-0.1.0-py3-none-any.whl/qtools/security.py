from Crypto.Cipher import AES
import pbkdf2
import os
import random
import string

__all__ = ['get_key_salt', 'encrypt', 'decrypt']



KEY_SIZE = 32  # 256-bit key
BLOCK_SIZE = 16  # 16-bit blocks
IV_SIZE = 16  # 128-bits to initialise
SALT_SIZE = 8  # 64-bits of salt



def get_key_salt(key):
    salt_seed = os.environ.get('QT_SALT_SEED', ''.join(random.sample(string.digits + string.ascii_letters, 18)))
    return pbkdf2.PBKDF2(key, salt_seed).read(SALT_SIZE)


def encrypt(plaintext, salt, p_phrase):

    # Initialise Cipher Randomly
    iv = os.urandom(IV_SIZE)

    # Prepare cipher key:
    key = pbkdf2.PBKDF2(p_phrase, salt).read(KEY_SIZE)

    cipher = AES.new(key, AES.MODE_CBC, iv)

    return iv + cipher.encrypt(plaintext.encode('utf8') +
                               (' '*(BLOCK_SIZE - (len(plaintext) % BLOCK_SIZE))).encode('utf8'))


def decrypt(cipher_text, salt, p_phrase):
    ''' Reconstruct the cipher object and decrypt. Will not preserve trailing whitespace in the retrieved value!'''

    # Prepare cipher key:
    key = pbkdf2.PBKDF2(p_phrase, salt).read(KEY_SIZE)

    # Extract IV:
    iv = cipher_text[:IV_SIZE]
    cipher_text = cipher_text[IV_SIZE:]

    cipher = AES.new(key, AES.MODE_CBC, iv)

    return cipher.decrypt(cipher_text).decode('utf8').strip(' ')