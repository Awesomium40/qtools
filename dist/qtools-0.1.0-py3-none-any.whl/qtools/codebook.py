from openpyxl.cell.cell import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo
from . import abc
from . import exceptions
import dotted_dict
import openpyxl
import re

__all__ = ['codebook']


class _StaticVars(object):

    __counter__ = 0


class QuestionType(abc.StringEnum):
    MUTLI_CHOICE = 'MC'
    DESCRIPTIVE_TEXT = "DB"
    MATRIX = "Matrix"
    TEXT_ENTRY = "TE"
    SLIDER = "Slider"
    RANK_ORDER = "RO"
    SIDE_BY_SIDE = "SBS"


class Selector(abc.StringEnum):
    BIPOLAR = 'Bipolar'
    DROP_LIST = "DL"
    FILE_BOX = 'FLB'
    GRAPHIC_BOX = 'GRB'
    HORIZONTAL_BAR = 'HBAR'
    LIKERT = 'Likert'
    MULTI_ANS_COL = 'MACOL'
    MULTI_ANS_HOR = 'MAHR'
    MULTI_LINE = 'ML'
    MUTLI_ANS_VERT = 'MAVR'
    MULTI_SELECT_BOX = "MSB"
    SBS_MATRIX = 'SBSMatrix'
    SELECT_BOX = 'SB'
    SINGLE_ANS_COL = 'SACOL'
    SINGLE_ANS_HOR = 'SAHR'
    SINGLE_LINE = 'SL'
    SINGLE_ANS_VERT = 'SAVR'
    TEXT_BOX = 'TB'
    VR = 'VR'


class SubSelector(abc.StringEnum):
    DROP_LIST = 'DL'
    DRAG_DROP = "DND"
    MULT_ANS = "MultipleAnswer"
    NULL = None
    SINGLE_ANS = 'SingleAnswer'
    TX = "TX"
    WOTXB = "WOTXB"


def codebook(**kwargs):
    """
    survey_codebook(**kwargs) -> openpyxl.Workbook
    :param kwargs:
    :return:
    """
    COL_HEADERS = ['QuestionID', 'Variable Name', 'Variable Label', 'Value Labels']

    WIDTHS = {"A": 10.3, "B": 21.5, "C": 44.3, "D": 27.9}
    ALIGNMENTS = {"A": openpyxl.styles.Alignment(),
                  "B": openpyxl.styles.Alignment(),
                  "C": openpyxl.styles.Alignment(),
                  "D": openpyxl.styles.Alignment(wrapText=True)}

    TBL_STYLE = TableStyleInfo(name="TableStyleMedium8",
                               showRowStripes=True)

    survey = dotted_dict.PreserveKeysDottedDict(**kwargs)
    wb = openpyxl.Workbook()
    flow = survey.get('flow')

    for i, element in enumerate(filter(lambda x: x.get('type') == 'Block', flow)):
        block = survey.blocks.get(element.get('id'))
        if block is None:
            raise exceptions.JsonException(f"Unable to locate Block with ID {element.get('id')}")

        # Create/get a sheet for the block to be processed and prepare it with formatting
        ws = wb.active if i == 0 else wb.create_sheet()
        for key, value in WIDTHS.items():
            ws.column_dimensions[key].width = value

        title = _sanitize_for_spss_(block.description)
        ws.title = title
        ws.append(COL_HEADERS)

        # The, retrieve the question data and add it to the sheet
        question_data = _process_block_(block, survey.get('questions'), survey.get('exportColumnMap'))
        for row in question_data:
            ws.append(str(itm) for itm in row)

        # Make a table
        max_row = ws.max_row
        if max_row > 1:
            tbl = Table(displayName=title, ref="A1:D{0}".format(max_row))
            tbl.tableStyleInfo = TBL_STYLE
            ws.add_table(tbl)

        # Styles have to be set on cells one at a time or they won't take
        for row_index, row in enumerate(ws.iter_rows(), 1):
            for column_index, cell in enumerate(row, 1):
                column_letter = get_column_letter(column_index)
                ws.cell(row_index, column_index).alignment = ALIGNMENTS.get(column_letter,
                                                                            openpyxl.styles.Alignment())

    return wb


def _process_block_(block, questions, columns):
    """
    process_block(block, questions, columns) -> list[tuple[str, str, str, dict]]
    Processed a block and returns a tuple [question_id, variable_name, variable_label, value_labels] for each
    question to be exported within the block
    :param block: The block to be processed
    :param questions: DottedDict of questions
    :param columns: DottedDict of exportColumnMap
    :return: list
    """
    question_map = {QuestionType.MUTLI_CHOICE.value: _mc_question_,
                    QuestionType.MATRIX.value: _matrix_question_,
                    QuestionType.SIDE_BY_SIDE.value: _sbs_question}
    rows = []
    question_elements = filter(lambda x: x.get('type') == 'Question', block.get('elements'))
    for question in question_elements:
        qid = question.get('questionId')
        question = questions.get(qid)
        block_columns = dict(filter(lambda itm: itm[1].get('question') == qid, columns.items()))
        if question.questionType.type != 'DB':
            process_func = question_map.get(question.questionType.type, generic_question)
            rows.extend(process_func(qid, question, block_columns))

    return rows


def generic_question(question_id, question, columns):

    var_name, column = next(filter(lambda x: x[1].question == question_id, columns.items()))
    return[(question_id, var_name,
            question.questionLabel if question.questionLabel is not None else question.questionText,
            None,)]


def _matrix_question_(question_id, question, columns, matrix_column_id=None):

    question_rows = []
    choice_base = r'{question_id}.columns.{matrix_column_id}.choices.{choice_id}' if matrix_column_id is not None \
        else r'{question_id}.choices.{choice_id}'
    subq_base = r'{question_id}.subQuestions.{sub_question_id}'
    te_base = r'{question_id}.subQuestions.{sub_question_id}.textEntry'
    has_text_entry = _has_text_entry_(question.subQuestions)
    is_multi_answer = _is_multi_answer_(question)
    var_label_base = question.questionLabel if question.questionLabel is not None else question.questionText

    for sub_question_id, sub_question in question.subQuestions.items():
        subq_string = subq_base.format(**locals())
        is_text_entry = False if not has_text_entry else _is_text_entry_choice_(sub_question)
        var_label = f"{var_label_base} - {sub_question.description}"

        # Multi-answer Matrix questions have one variable per choice/sub-question combo,
        # plus an extra for each sub-question with TextEntry
        if is_multi_answer:
            for choice_id, choice in question.choices.items():
                choice_string = choice_base.format(**locals())
                var_label = f'{var_label} - {choice.description}'
                value_labels = {1: choice.description}
                var_name, sub_question_column = next(filter(lambda x: x[1].subQuestion == subq_string
                                                            and x[1].get('choice') == choice_string
                                                            and x[1].get('textEntry') is None,
                                                            columns.items()))
                if is_text_entry:
                    te_string = te_base.format(**locals())

                    t_var_name, tsqc = next(filter(lambda x: x[1].subQuestion == subq_string
                                                   and x[1].get('textEntry') == te_string,
                                                   columns.items()))
                    question_rows.extend([(question_id, _sanitize_for_spss_(var_name), var_label, value_labels,),
                                          (question_id, _sanitize_for_spss_(t_var_name), f'{var_label} - Text', None,)])
                else:
                    question_rows.append((question_id, _sanitize_for_spss_(var_name), var_label, value_labels))

        # Single-answer matrix questions have only a single variable for each sub-question, plus an extra for each
        # sub-question that has text entry
        else:
            value_labels = {value.recode: value.description for key, value in question.choices.items()}
            if is_text_entry:
                var_name, sub_question_column = next(filter(lambda x: x[1].subQuestion == subq_string
                                                            and x[1].get('textEntry') is None,
                                                            columns.items()))
                t_var_name, tsqc = next(filter(lambda x: x[1].subQuestion == subq_string
                                               and x[1].get('textEntry') is not None,
                                               columns.items()))
                question_rows.extend([(question_id, _sanitize_for_spss_(var_name), var_label, value_labels,),
                                      (question_id, _sanitize_for_spss_(t_var_name), f'{var_label} - Text', None,)])
            else:
                var_name, sub_question_column = next(filter(lambda x: x[1].subQuestion == subq_string, columns.items()))
                question_rows.append((question_id, var_name, var_label, value_labels))

    return question_rows


def _mc_question_(question_id, question, columns):

    question_rows = []
    _choice_base = r'{question_id}.choices.{choice_id}'
    _te_string = _choice_base + '.textEntry'
    has_text_entry = _has_text_entry_(question.choices)
    label_base = question.questionLabel if question.questionLabel is not None else question.questionText

    # Multi-answer questions have columns corresponding to each choice, plus an extra column
    # for text entry on any text-entry choices
    if _is_multi_answer_(question):
        for choice_id, choice in question.choices.items():
            choice_str = _choice_base.format(**locals())
            te_str = _te_string.format(**locals())
            var_name, choice_column = next(filter(lambda x: x[1].get('choice') == choice_str, columns.items()))
            if has_text_entry and _is_text_entry_choice_(choice):
                label = label_base + " - TextEntryChoice - Text"
                var_name, te_column = next(filter(lambda x: x[1].get('textEntry') == te_str, columns.items()))
                question_rows.append((question_id, var_name, label, None,))
            elif has_text_entry:
                label = label_base + " - Selected Choice"
                question_rows.append((question_id, var_name, label, None,))
            else:
                question_rows.append((question_id, var_name, f'{label_base} {choice.description}',
                                      {'1': choice.description}))
    else:
        var_label = label_base
        items = columns.items()
        value_labels = {value.recode: value.description for key, value in question.choices.items()}
        if has_text_entry:
            var_name, column = next(filter(lambda x: not x[0].endswith("_TEXT"), items))
            question_rows.append((question_id, var_name, label_base + " - Selected Choice", value_labels,))
            var_name, column = next(filter(lambda x: x[0].endswith("_TEXT"), items))
            question_rows.append((question_id, var_name, f'{label_base} - TextEntryChoice - Text', None,))
        else:
            var_name, column = next(filter(lambda x: x[1].question == question_id, items))
            question_rows.append((question_id, var_name, label_base, value_labels,))

    return question_rows


def _rank_order_question(question_id, question, columns):

    question_rows = []
    choice_base = r'{question_id}.choices.{choice_id}'
    var_label_base = question.questionLabel if question.questionLabel is not None else question.questionText
    for choice_id, choice in question.choices.items():
        value_labels = {choice_id: choice.recode}
        choice_str = choice_base.format(**locals())
        var_label = f'{var_label_base} - {choice.description}'
        var_name, column = next(filter(lambda x: x[1].choice == choice_str, columns.items()))
        question_rows.append((question_id, var_name, var_label, value_labels))

    return question_rows


def _sbs_question(question_id, question, columns):

    column_base = r"{question_id}.columns.{column_id}"
    choice_base = r'{question_id}.choices.{choice_id}'
    sub_question_base = r'{question_id}.subQuestions.{sub_question_id}'
    question_rows = []
    question_label = question.questionLabel if question.questionLabel is not None else question.questionText

    for column_id, column in question.columns.items():
        column_label = column.questionLabel if column.questionLabel is not None else column.questionText
        column['subQuestions'] = question.subQuestions
        column['questionLabel'] = f'{question_label} - {column_label}'
        question_rows.extend(_matrix_question_(question_id, column, columns, matrix_column_id=column_id))

    return question_rows


def _text_entry_question(question_id, question, columns):
    pass


def _get_choice_(column, question):

    choice_re = re.compile(r"^(?P<question_id>{qid})[.]choices[.](?P<choice>[0-9]+)$"
                           .format(qid=column.get('question')))

    choice_id = choice_re.match(column.get('choice'))['choice']
    return question.choices.get(choice_id)


def _get_question_(column, questions):
    qid = column.get('question')
    question = questions.get(qid)
    return question


def _get_sub_question_(column, question):

    sub_q_re = re.compile(r"^(?P<question_id>{qid})[.]subQuestions[.](?P<sub_q>[0-9]+)$"
                            .format(qid=column.get('question')))

    sub_id = sub_q_re.match(column.get('subQuestion'))['sub_q']
    return question.subQuestions.get(sub_id)


def _has_text_entry_(choices):
    return any(choice.get('textEntry') is not None for id, choice in choices.items())


def _is_multi_answer_(question):
    return (question.questionType.type == QuestionType.MUTLI_CHOICE.value and
            question.questionType.selector in (Selector.MULTI_ANS_HOR.value, Selector.MUTLI_ANS_VERT.value,
                                               Selector.MULTI_ANS_COL.value, Selector.MULTI_SELECT_BOX.value)) \
           or (question.questionType.type == QuestionType.MATRIX.value and
               question.questionType.subSelector == SubSelector.MULT_ANS.value)


def _is_text_entry_choice_(choice):
    return choice.get('textEntry') is not None


def _multi_replace_(txt, repl, ignore_case=False, whole_word_only=False):
    """
    caastools.utils._multi_replace_(text, repl, ignore_case=False, whole_word_only=False) -> str
    Performs simultaneous multi-replacement of substrings within a string
    :param txt: string in which replacements are to be performed
    :param repl: dictionary mapping substrings to be replaced with their replacements
    :param ignore_case: specifies whether to ignore case in search/replacement. Default False
    :param whole_word_only: specifies whether to replace only on whole word matches. Default False
    :return: string with replacements made
    """

    repl_str = "{0}{{0}}{0}".format("\\b" if whole_word_only else '')

    # The problem is that there is the risk of having one replacement be
    # the substring of another. Deal with this issue by sorting long to short
    replacements = sorted(repl, key=len, reverse=True)

    # Next, we can just use the regex engine to do the replacements all at once
    # Preferable to iteration because sequential replacement may cause undesired results
    replace_re = re.compile("|".join(map(lambda x: repl_str.format(re.escape(x)), replacements)),
                            re.IGNORECASE if ignore_case else 0)

    return replace_re.sub(lambda match: repl[match.group(0)], txt)


def _sanitize_for_spss_(dirty_str, sub=None):
    """
    _sanitize_for_spss_(str, subs={}) -> str
    Sanitizes the provided string into an SPSS-Compatible identifier
    :param dirty_str: the string to be sanitized
    :param sub: A dictionary of substitutions to use in the santization process. Keys will be replaced with values
    in the sanitized string. Note that using unsanitary values will cause custom substitutions to themselves be sanitized.
    Default None
    :return: str
    """
    # SPSS has specifications on variable names. These will help ensure they are met
    max_length = 32
    invalid_chars = re.compile(r"[^a-zA-Z0-9_.]")
    invalid_starts = re.compile(r"[^a-zA-Z]+")
    subs = {} if sub is None else sub

    # Remove invalid starting characters
    start_invalid = invalid_starts.match(dirty_str)
    new_var = invalid_starts.sub('', dirty_str, count=1) if start_invalid else dirty_str

    # Possible that the process of removing starting chars could create empty string,
    # so create valid var name in that case
    if len(new_var) == 0:
        _StaticVars.__counter__ += 1
        new_var = "VAR_{0}".format(_StaticVars.__counter__)

    # Trim off excess characters to fit into maximum allowable length
    new_var = new_var[:32] if len(new_var) > max_length else new_var

    # If any custom substitutions are required, perform prior to final sanitization
    if len(subs) > 0:
        new_var = _multi_replace_(new_var, subs)

    # locate invalid characters and replace with underscores
    replacements = {x: "_" for x in invalid_chars.findall(new_var)}
    new_var = _multi_replace_(new_var, replacements) if len(replacements) > 0 else new_var

    return new_var


def _value_labels_(column, question):

    if _is_text_entry_choice_(column):
        value_labels = None
    elif question.questionType.type not in (QuestionType.MATRIX.value, QuestionType.MUTLI_CHOICE.value):
        value_labels = None
    else:
        if _is_multi_answer_(question):
            choice = _get_choice_(column, question)
            value_labels = None if _is_text_entry_choice_(choice) else {1: choice.description}
        else:
            value_labels = {int(choice.recode): choice.description for key, choice in question.choices.items()}

    return value_labels
